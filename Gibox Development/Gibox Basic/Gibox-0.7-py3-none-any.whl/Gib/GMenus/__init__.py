from Gib import GWidget


class GMenuShell(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuShell()

    def AddMenu(self, Widget):
        self.Widget.append(child=Widget.Get())

    def AddMenuItem(self, Widget):
        self.Widget.prepend(child=Widget.Get())

    def Deactivate(self):
        self.Widget.deactivate()

    def Deselect(self):
        self.Widget.deselect()

    def GetParent(self):
        return self.Widget.get_parent_shell()

    def GetSelectItem(self):
        return self.Widget.get_selected_item()

    def Canel(self):
        self.Widget.cancel()


class GMenuBar(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuBar()


class GMenu(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Menu()

    def SetTearOff(self, State: bool = False):
        self.Widget.set_tearoff_state(torn_off=State)

    def SetTitle(self, Title: str = "Gib.GMenus.GMenu"):
        self.Widget.set_title(title=Title)

    def Detach(self):
        self.Widget.detach()

    def DeleteMenu(self):
        self.Widget.popdown()


class GMenuItem(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuItem()

    def SetLabel(self, Label: str = "Gib.GMenus.GMenuItem"):
        self.Widget.set_label(label=Label)

    def SetSubMenu(self, Widget):
        self.Widget.set_submenu(Widget)
