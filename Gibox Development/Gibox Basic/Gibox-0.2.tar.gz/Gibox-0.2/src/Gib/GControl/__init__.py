from Gib import GWidget, GEditable


class GLabel(GWidget):
    def __init__(self, Text: str = "Gib.Control.GLabel"):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Label()
        self.SetText(Text)

    def SetText(self, Text: str):
        self.Widget.set_label(Text)

    def SetSelectable(self, Value: bool):
        self.Widget.set_selectable(Value)

    def GetText(self):
        return self.Widget.get_label()


class GButton(GWidget):
    def __init__(self, Label: str = "Gib.GControl.GButton"):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Button(label=Label)

    def SetLabel(self, Label: str):
        self.Widget.set_label(Label)

    def SetAngle(self, Angle: int):
        self.Widget.set_angle(Angle)

    def SetShortcutKeyWithLabel(self, Label: str):
        self.Widget.new_with_mnemonic(label="_"+Label)

    def GetLabel(self):
        return self.Widget.get_label()

    def Click(self, EventFunc):
        self.Widget.connect("clicked", EventFunc)

    def Clicked(self):
        self.Widget.clicked()

    def ClickedDo(self):
        self.Widget.do_clicked()


class GEntry(GEditable):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Entry

    def SetText(self, Text: str):
        self.Widget.set_text(text=Text)

    def SetProgress(self, Value: int):
        self.Widget.set_progress_pulse_step(fraction=Value)

    def GetText(self):
        return self.Widget.get_text()

    def GetTextLength(self):
        return self.Widget.get_text_length()


class GSwitch(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Switch()

    def SetActive(self, Active: bool):
        self.Widget.get_active(is_state=Active)

    def SetState(self, State: bool):
        self.Widget.set_state(state=State)

    def DoActivate(self):
        self.Widget.do_activate()

    def GetActive(self):
        return self.Widget.get_active()

    def GetState(self):
        return self.Widget.get_state()


class GTextView(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.TextView()


class GProgressBar(GWidget):
    def __init__(self, ShowText=False):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.ProgressBar(show_text=ShowText)

    def SetProgress(self, Progress: int = 0):
        self.Widget.set_text(Progress)

    def Pulse(self):
        self.Widget.pulse()


class GBox(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Box()


class GNoteBook(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Notebook()

    def AddPage(self, Widget: GWidget or None, Label: GLabel):
        self.Widget.append_page(child=Widget.Get(), tab_label=Label.Get())

    def AddPageMenu(self, Widget: GWidget or None, Label: GLabel,
                    MenuLabel: str = "Gib.GControl.GWidget"):
        self.Widget.append_page_menu(child=Widget.Get(), tab_label=Label.Get(), menu_label=MenuLabel)

    def SetPageLabel(self, Widget: GWidget, Label: str):
        self.Widget.set_menu_label(child=Widget.Get(), menu_label=Label)

    def SetPageShow(self, Value: bool):
        self.Widget.set_show_tabs(show_tabs=Value)

    def SetScrollable(self, Value: bool):
        self.Widget.set_scrollable(scrollable=Value)

    def RemovePage(self, Page: int = 0):
        self.Widget.remove_page(page_num=Page)

    def DeletePage(self, Widget: GWidget):
        self.Widget.detach_tab(child=Widget.Get())