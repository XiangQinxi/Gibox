class GtBin(object):
    def __init__(self):
        self.Widget = None