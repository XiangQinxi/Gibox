from Gib import GWidget


class GWindow(GWidget):
    def __init__(self, Title: str = "Gib.GContainer.GWindow"):
        super().__init__()
        self.Init()

        from gi.repository import Gtk

        self.Widget = Gtk.Window()
        self.SetTitle(Title)
        self.SetDefaultSize(1080, 640)

    def Move(self, X: int, Y: int):
        self.Widget.move(x=X, y=Y)

    def Maximize(self):
        self.Widget.maximize()

    def IfMaximize(self):
        return self.Widget.is_maximized()

    def SetTitle(self, Title: str):
        self.Widget.set_title(Title)

    def SetSize(self, X: int, Y: int):
        self.Widget.move(x=X, y=Y)

    def SetBounds(self, Width: int, Height: int):
        self.Widget.resize(width=Width, height=Height)

    def SetDefaultBounds(self, Width: int, Height: int):
        self.Widget.set_default_size(Width, Height)

    def SetDefaultWidget(self, DefaultWidget=None):
        self.Widget.set_default_widget(DefaultWidget)

    def SetDeleltButton(self, DeleltButton: bool):
        self.Widget.set_deletable(DeleltButton)

    def SetDestroyWithParent(self, DestroyWithParent):
        self.Widget.set_destroy_with_parent(setting=DestroyWithParent)

    def SetUnMaximize(self):
        self.Widget.unmaximize()

    def SetStartID(self, StartId):
        self.Widget.set_startup_id(startup_id=StartId)

    def SetSkipTaskbarHint(self, SkipTaskbarHint: bool):
        self.Widget.set_skip_taskbar_hint(setting=SkipTaskbarHint)

    def SetApplication(self, Application):
        self.Widget.set_application(application=Application)

    def GetDefaultBounds(self):
        return self.Widget.get_default_size()

    def GetDeleteButton(self):
        return self.Widget.get_deletable()

    def GetPosition(self):
        return self.Widget.get_position()

    def GetBounds(self):
        return self.Widget.get_size()

    def Close(self):
        self.Widget.close()

    def Run(self):
        from gi.repository import Gtk

        self.Widget.connect("delete-event", Gtk.main_quit)
        self.ShowAll()
        Gtk.main()


class GApplication(GWindow):
    def __init__(self):
        super().__init__()
        self.Init()

        from gi.repository import Gtk

        self.Widget = Gtk.Application()

    def AddWindow(self, Window: GWindow):
        self.Widget.add_window(window=Window)


class GDialog(GWindow):
    def __init__(self):
        super().__init__()
        self.Init()

        from gi.repository import Gtk

        self.Widget = Gtk.Dialog()

    def Response(self, ID: int):
        self.Widget.response(response_id=ID)

    def AddActionWidget(self, Widget: GWidget, ID: int):
        self.Widget.add_action_widget(child=Widget.Get(), response_id=ID)

    def AddButton(self, Text: str, ID: int):
        self.Widget.add_button(button_text=Text, response_id=ID)


class GAboutDialog(GDialog):
    def __init__(self):
        super().__init__()
        self.Init()

        from gi.repository import Gtk
        self.Widget = Gtk.AboutDialog()

    def SetAuthors(self, Authors: str or None):
        self.Widget.set_authors(authors=Authors)

    def SetNotes(self, Notes: str or None):
        self.Widget.set_comments(comments=Notes)

    def SetCopyright(self, Copyright: str or None):
        self.Widget.set_copyright(copyright=Copyright)

    def SetDocumenters(self, Documenters: str or None):
        self.Widget.set_documenters(documenters=Documenters)

    def SetLicense(self, License: str or None):
        self.Widget.set_license(license=License)

    def SetLicenseType(self, LicenseType: str or None):
        self.Widget.set_license_type(license_type=LicenseType)

    def SetProgramName(self, Name: str):
        self.Widget.set_program_name(name=Name)

    def SetVersion(self, Version: str or None):
        self.Widget.set_version(version=Version)

    def SetWebsite(self, Website: str or None):
        self.Widget.set_website(website=Website)

    def SetWebsiteLabel(self, WebsiteLabel: str or None):
        self.Widget.set_website_label(website_label=WebsiteLabel)
