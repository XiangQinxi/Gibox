class GIcon(object):
    def __init__(self, Icon, ):
        self.Init()
        from gi.repository import Gio
        self.Widget = Gio.Icon(Icon)

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")