from Gib.Gibox import *


class XGObject(GObject):
    def __init__(self):
        super().__init__()
        self.EventId = None
        from gi.repository import GObject
        self.Widget = GObject.Object()


class XGWidget(GWidget):
    def Init(self):
        import gi
        gi.require_version("Gtk", "4.0")


class XGApplication(GApplication):
    def Init(self):
        from gi import require_version
        require_version("Gtk", "4.0")


class XGWindow(GWindow):
    def SetChild(self, Child: GWidget):
        self.Widget.set_child(Child)