from Gib.GContainer import GWindow


class GExample(object):
    def __init__(self):
        self.Init()
        self.Code()

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")

    def Code(self):
        pass

    def Run(self):
        pass


class HelloWorld(GExample):
    def __init__(self):
        super().__init__()
        self.Init()
        from Gib.GContainer import GWindow
        from Gib.GControl import GButton
        self.Window = GWindow()
        self.Window.SetDefaultBounds(450, 200)

        self.Button = GButton(Label="Click Here")
        self.Button.Click(self.Click)
        self.Window.Add(self.Button)

    def Click(self, Widget):
        print("Hello,World")

    def Run(self):
        from gi.repository import Gtk

        self.Window.Event("delete-event", Gtk.main_quit)
        self.Window.ShowAll()
        Gtk.main()
