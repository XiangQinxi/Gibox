class GiBox(object):
    def __init__(self):
        from gi import require_version
        require_version("Gtk", "3.0")

        from gi.repository import Gtk

        self.quit = Gtk.main_quit()
        self.mainloop = Gtk.main()


class GObject(object):
    def __init__(self):
        self.EventId = None
        from gi.repository import GObject
        self.Widget = GObject.Object()

    def Event(self, BindName: str, BindFunc):
        self.EventId = self.Widget.connect(BindName, BindFunc)


class GWidget(GObject):
    def __init__(self):
        super().__init__()
        self.Init()

        self.Widget = None

    def Init(self):
        import gi
        gi.require_version("Gtk", "3.0")

    def SetVersion(self, Version: float = 3.0):
        from gi import require_version
        require_version("Gtk", str(Version))

    def GetChildren(self):
        return self.Widget.get_children()

    def Remove(self, Widget):
        self.Widget.remove(widget=Widget.Get())

    def DoRemove(self, Widget):
        self.Widget.do_remove(widget=Widget.Get())

    def Add(self, Widget):
        self.Widget.add(widget=Widget.Get())

    def DoAdd(self, Widget):
        self.Widget.do_add(widget=Widget.Get())

    def Activated(self):
        self.Widget.activate()

    def Destroy(self):
        self.Widget.destroy()

    def DoDestroy(self):
        self.Widget.do_destroy()

    def DoDestroyEvent(self, event):
        self.Widget.do_destroy_event(event=event)

    def DeleteWindow(self, Window):
        self.Widget.unregister_window(window=Window.Get())

    def DoPressButton(self):
        self.Widget.do_button_press_event()

    def DoReleaseButton(self):
        self.Widget.do_button_release_event()

    def GetMarginLeft(self):
        self.Widget.get_margin_start()

    def GetMarginRight(self):
        self.Widget.get_margin_end()

    def GetMarginTop(self):
        self.Widget.get_margin_top()

    def GetMarginBottom(self):
        self.Widget.get_margin_bottom()

    def Show(self):
        self.Widget.show()

    def ShowAll(self):
        self.Widget.show_all()

    def ShowNow(self):
        self.Widget.show_now()

    def DoShow(self):
        self.Widget.do_show()

    def DoShowAll(self):
        self.Widget.do_show_all()

    def Hide(self):
        self.Widget.hide()

    def DoHide(self):
        self.Widget.do_hide()

    def SetID(self, ID: int or None):
        self.Widget.set_id(id=ID)

    def SetStateFlags(self, Flags, Clear: bool = False):
        self.Widget.set_state_flags(flags=Flags, clear=Clear)

    def SetStateNORMAL(self):
        self.SetStateFlags("NORMAL")

    def SetStateACTIVE(self):
        self.SetStateFlags("ACTIVE")

    def SetParent(self, Parent):
        self.Widget.set_parent(parent=Parent.Get())

    def SetParentWindow(self, ParentWindow):
        self.Widget.set_parent_window(parent_window=ParentWindow.Get())

    def SetResizable(self, Resizable: bool):
        self.Widget.set_resizable(Resizable)

    def SetDefaultSize(self, Width: int, Height: int):
        self.Widget.set_default_size(Width, Height)

    def SetDefaultWidth(self, Width: int):
        self.SetDefaultSize(Width=Width, Height=self.GetDefaultSize()[1])

    def SetDefaultHeight(self, Height: int):
        self.SetDefaultSize(Width=self.GetDefaultSize()[0], Height=Height)

    def SetAlpha(self, Alpha: float):
        self.Widget.set_opacity(opacity=Alpha)

    def SetMiniSize(self, Width: int, Height: int):
        self.Widget.set_size_request(width=Width, height=Height)

    def SetToolTip(self, Text: str):
        self.Widget.set_tooltip_text(text=Text)

    def SetToolTipWindow(self, Window):
        self.Widget.set_tooltip_window(custom_window=Window.Get())

    def SetName(self, Name: str):
        self.Widget.set_name(name=Name)

    def GetName(self):
        """
        :return: int
        """
        self.Widget.get_name()

    def GetAlpha(self):
        return self.Widget.get_opacity()

    def GetResizable(self):
        return self.Widget.get_resizable()

    def GetDefaultSize(self):
        return self.Widget.get_default_size()

    def Get(self):
        return self.Widget


class GEditable(object):
    def __init__(self):
        from gi.repository import Gtk
        self.Widget = Gtk.Editable()

    def Copy(self):
        self.Widget.copy_clipboard()

    def Cut(self):
        self.Widget.cut_clipboard()

    def DeleteSelectionText(self):
        self.Widget.delete_selection()

    def DeleteText(self, Start: int, End: int):
        self.Widget.delete_text(start_pos=Start, end_pos=End)

    def GetChars(self, Start: int, End: int):
        return self.Widget.get_chars(start_pos=Start, end_pos=End)

    def GetEditable(self):
        return self.Widget.get_editable()

    def GetPosition(self):
        return self.Widget.get_position()

    def GetSelectPosition(self):
        return self.Widget.get_selection_bounds()

    def InsertText(self, Text: str, Pos: int):
        self.Widget.insert_text(text=Text, position=Pos)


class GAppChooser(object):
    def __init__(self):
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.AppChooser()

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")

    def SetVersion(self, Version: float = 3.0):
        from gi import require_version
        require_version("Gtk", str(Version))

    def GetAppInfo(self):
        return self.Widget.get_app_info()

    def GetContentType(self):
        return self.Widget.get_content_type()

    def Refresh(self):
        self.Widget.refresh()


class GBind(object):
    def __init__(self):
        self.Clicked = "clicked"
        self.Activate = "activate"
        self.Enter = "enter"
        self.Leave = "leave"
        self.Pressed = "pressed"
        self.Released = "released"
        self.Swich_Acitvate = "activate"
        self.Swich_State = "state-set"


class RGBA(object):
    def __init__(self, Red: float = 1.0, Green: float = 1.0, Blue: float = 1.0, Alpha: float = 1.0):
        from gi.repository import Gdk

        self.Widget = Gdk.RGBA(red=Red, green=Green, blue=Blue, alpha=Alpha)