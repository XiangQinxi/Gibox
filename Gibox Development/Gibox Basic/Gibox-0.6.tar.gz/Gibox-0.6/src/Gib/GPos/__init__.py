class GPosition(object):
    def __init__(self):
        self.Init()
        from gi.repository.Gtk import PositionType
        self.Top = PositionType.TOP
        self.Bottom = PositionType.BOTTOM
        self.Left = PositionType.LEFT
        self.Right = PositionType.RIGHT

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")