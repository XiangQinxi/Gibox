class GBuilder(object):
    def __init__(self):
        from gi import require_version
        require_version("Gtk", "3.0")
        from gi.repository import Gtk

        self.Window = None
        self.Widget = Gtk.Builder()

    def Load(self, File):
        self.Widget.add_from_file(File)

    def LoadWidget(self, Object: str):
        return self.Widget.get_object(Object)

    def Get(self):
        return self.Widget

    def GetObjectList(self):
        return self.Widget.get_objects()

    def Run(self, WindowID):
        from gi.repository import Gtk

        self.Window = self.LoadWidget(WindowID)
        self.Window.show_all()
        self.Window.connect("delete-event", Gtk.main_quit)

        Gtk.main()

    def HandleBind(self, Class):
        self.Widget.connect_signals(Class)