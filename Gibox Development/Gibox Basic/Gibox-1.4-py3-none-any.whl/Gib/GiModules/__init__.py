class GMl(object):
    def __init__(self):
        pass