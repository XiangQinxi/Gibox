from Gib import GWidget


class XWidget(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        self.Widget = None

    def Init(self):
        from gi import require_version
        require_version("Gtk", "4.0")