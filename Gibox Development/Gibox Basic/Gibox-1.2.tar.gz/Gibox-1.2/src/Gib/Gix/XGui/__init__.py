from Gib.GContainer import GApplicationWindow


class XApplication(object):
    def __init__(self, ApplicationId='Gix.XGui.XApplication'):
        from gi.repository import Gtk
        self.Widget = Gtk.Application(application_id=ApplicationId)

    def Get(self):
        return self.Widget

    def Run(self):
        self.Widget.run(None)


class XApplicationWindow(GApplicationWindow):
    def __init__(self, Title: str = "Gix.XGui.XApplicationWindow", Size=(450, 200)):
        super().__init__(self)
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.ApplicationWindow()
