class Glade(object):
    def Run(self):
        import os
        os.system("glade.exe")

class Demo(object):
    def Run(self):
        import os
        os.system("demo.exe")


if __name__ == '__main__':
    Run1 = Demo()
    Run1.Run()