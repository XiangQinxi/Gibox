class GiBox(object):
    def __init__(self):
        from gi import require_version
        require_version("Gtk", "3.0")

        from gi.repository import Gtk

        self.quit = Gtk.main_quit()
        self.mainloop = Gtk.main()


class GObject(object):
    def __init__(self):
        self.EventId = None
        from gi.repository import GObject
        self.Widget = GObject.Object()

    def Event(self, BindName: str, BindFunc):
        self.EventId = self.Widget.connect(BindName, BindFunc)


class GWidget(GObject):
    def __init__(self):
        super().__init__()
        self.Init()

        self.Widget = None

    def Init(self):
        import gi
        gi.require_version("Gtk", "3.0")

    def SetVersion(self, Version: float = 3.0):
        from gi import require_version
        require_version("Gtk", str(Version))

    def GetChildren(self):
        return self.Widget.get_children()

    def Remove(self, Widget):
        self.Widget.remove(widget=Widget.Get())

    def DoRemove(self, Widget):
        self.Widget.do_remove(widget=Widget.Get())

    def Add(self, Widget):
        self.Widget.add(widget=Widget.Get())

    def DoAdd(self, Widget):
        self.Widget.do_add(widget=Widget.Get())

    def Activated(self):
        self.Widget.activate()

    def Destroy(self):
        self.Widget.destroy()

    def DoDestroy(self):
        self.Widget.do_destroy()

    def DoDestroyEvent(self, event):
        self.Widget.do_destroy_event(event=event)

    def DeleteWindow(self, Window):
        self.Widget.unregister_window(window=Window.Get())

    def DoPressButton(self):
        self.Widget.do_button_press_event()

    def DoReleaseButton(self):
        self.Widget.do_button_release_event()

    def GetMarginLeft(self):
        self.Widget.get_margin_start()

    def GetMarginRight(self):
        self.Widget.get_margin_end()

    def GetMarginTop(self):
        self.Widget.get_margin_top()

    def GetMarginBottom(self):
        self.Widget.get_margin_bottom()

    def Show(self):
        self.Widget.show()

    def ShowAll(self):
        self.Widget.show_all()

    def ShowNow(self):
        self.Widget.show_now()

    def DoShow(self):
        self.Widget.do_show()

    def DoShowAll(self):
        self.Widget.do_show_all()

    def Hide(self):
        self.Widget.hide()

    def DoHide(self):
        self.Widget.do_hide()

    def SetID(self, ID: int or None):
        self.Widget.set_id(id=ID)

    def SetStateFlags(self, Flags, Clear: bool = False):
        self.Widget.set_state_flags(flags=Flags, clear=Clear)

    def SetStateNORMAL(self):
        self.SetStateFlags("NORMAL")

    def SetStateACTIVE(self):
        self.SetStateFlags("ACTIVE")

    def SetParent(self, Parent):
        self.Widget.set_parent(parent=Parent.Get())

    def SetParentWindow(self, ParentWindow):
        self.Widget.set_parent_window(parent_window=ParentWindow.Get())

    def SetResizable(self, Resizable: bool):
        self.Widget.set_resizable(Resizable)

    def SetDefaultSize(self, Width: int, Height: int):
        self.Widget.set_default_size(Width, Height)

    def SetDefaultWidth(self, Width: int):
        self.SetDefaultSize(Width=Width, Height=self.GetDefaultSize()[1])

    def SetDefaultHeight(self, Height: int):
        self.SetDefaultSize(Width=self.GetDefaultSize()[0], Height=Height)

    def SetAngle(self, Angle: int):
        self.Widget.set_angle(Angle)

    def SetAlpha(self, Alpha: float):
        self.Widget.set_opacity(opacity=Alpha)

    def SetMiniSize(self, Width: int, Height: int):
        self.Widget.set_size_request(width=Width, height=Height)

    def SetToolTip(self, Text: str):
        self.Widget.set_tooltip_text(text=Text)

    def SetToolTipWindow(self, Window):
        self.Widget.set_tooltip_window(custom_window=Window.Get())

    def SetName(self, Name: str):
        self.Widget.set_name(name=Name)

    def GetName(self):
        """
        :return: int
        """
        self.Widget.get_name()

    def GetAlpha(self):
        return self.Widget.get_opacity()

    def GetResizable(self):
        return self.Widget.get_resizable()

    def GetDefaultSize(self):
        return self.Widget.get_default_size()

    def AddEvent(self, Func):
        self.Widget.connect("add", Func)

    def Get(self):
        return self.Widget


class GImage(GObject):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Image()

    def SetIcon(self, IconName: str or None, Size: int):
        self.Widget.set_from_icon_name(icon_name=IconName, size=Size)

    def SetIconFile(self, IconFile: str or None):
        self.Widget.set_from_resource(resource_path=IconFile)


class GEditable(object):
    def __init__(self):
        from gi.repository import Gtk
        self.Widget = Gtk.Editable()

    def Copy(self):
        self.Widget.copy_clipboard()

    def Cut(self):
        self.Widget.cut_clipboard()

    def DeleteSelectionText(self):
        self.Widget.delete_selection()

    def DeleteText(self, Start: int, End: int):
        self.Widget.delete_text(start_pos=Start, end_pos=End)

    def GetChars(self, Start: int, End: int):
        return self.Widget.get_chars(start_pos=Start, end_pos=End)

    def GetEditable(self):
        return self.Widget.get_editable()

    def GetPosition(self):
        return self.Widget.get_position()

    def GetSelectPosition(self):
        return self.Widget.get_selection_bounds()

    def InsertText(self, Text: str, Pos: int):
        self.Widget.insert_text(text=Text, position=Pos)


class GAppChooser(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.AppChooser()

    def GetAppInfo(self):
        return self.Widget.get_app_info()

    def GetContentType(self):
        return self.Widget.get_content_type()

    def Refresh(self):
        self.Widget.refresh()


class GAppChooserButton(GAppChooser):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.AppChooserButton()

    def AddCustomItem(self, Name: str, Label: str, Icon):
        self.Widget.append_custiom_item(name=Name, label=Label, icon=Icon)

    def AddSeparator(self):
        self.Widget.append_separator()

    def GetHeading(self):
        return self.Widget.get_heading()

    def GetShowDefaultItem(self):
        return self.Widget.get_show_default_item()

    def GetShowDialogItem(self):
        return self.Widget.get_show_dialog_item()

    def SetActiveCustomItem(self, Name: str):
        self.Widget.set_active_custom_item(name=Name)


class GApplication(object):
    def __init__(self, ApplicationId: str = "Gib.GContainer.GApplication"):
        self.Init()

        from gi.repository import Gtk

        self.Widget = Gtk.Application(application_id=ApplicationId)

    def SetVersion(self, Version: float = 3.0):
        from gi import require_version
        require_version("Gtk", str(Version))

    def Init(self):
        self.SetVersion(3.0)

    def Run(self):
        self.Widget.run(None)

    def MainLoop(self, MainFunc):
        self.Widget.connect('activate', MainFunc)

    def AddWindow(self, Window: GWidget):
        self.Widget.add_window(window=Window)


class GLabel(GWidget):
    def __init__(self, Text: str = "Gib.Control.GLabel", Version: float = 3.0):
        super().__init__()
        self.SetVersion(Version)
        from gi.repository import Gtk
        self.Widget = Gtk.Label()
        self.SetText(Text)

    def SetText(self, Text: str):
        self.Widget.set_label(Text)

    def SetSelectable(self, Value: bool):
        self.Widget.set_selectable(Value)

    def GetText(self):
        return self.Widget.get_label()


class GButton(GWidget):
    def __init__(self, Label: str = "Gib.GControl.GButton", Version: float = 3.0):
        super().__init__()
        self.SetVersion(Version)
        from gi.repository import Gtk
        self.Widget = Gtk.Button(label=Label)

    def SetLabel(self, Label: str):
        self.Widget.set_label(Label)

    def SetAngle(self, Angle: int):
        self.Widget.set_angle(Angle)

    def SetShortcutKeyWithLabel(self, Label: str):
        self.Widget.new_with_mnemonic(label="_"+Label)

    def GetLabel(self):
        return self.Widget.get_label()

    def Click(self, EventFunc):
        self.Widget.connect("clicked", EventFunc)

    def Activate(self, EventFunc):
        self.Widget.connect("activate", EventFunc)

    def Enter(self, EventFunc):
        self.Widget.connect("enter", EventFunc)

    def Leave(self, EventFunc):
        self.Widget.connect("leave", EventFunc)

    def Pressed(self, EventFunc):
        self.Widget.connect("pressed", EventFunc)

    def Released(self, EventFunc):
        self.Widget.connect("released", EventFunc)

    def Clicked(self):
        self.Widget.clicked()

    def ClickedDo(self):
        self.Widget.do_clicked()


class GMenuButton(GWidget):
    def __init__(self, Popover):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuButton(popover=Popover.Get())

    def GetParent(self):
        return self.Widget.get_align_widget()

    def GetMenuModel(self):
        return self.Widget.get_menu_model()

    def GetPopover(self):
        return self.Widget.get_popover()

    def GetPopup(self):
        return self.Widget.get_popup()

    def GetUsePopover(self):
        return self.Widget.get_use_popover()


class GListStore(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.ListStore()

    def Append(self, Row=None):
        self.Widget.append(row=Row)

    def Clear(self):
        self.Widget.clear()

    def Insert(self, Position: int, Row=None):
        self.Widget.insert(position=Position, row=Row)


class GComboBox(GWidget):
    def __init__(self, Model: str = "<<Option>>", Additional: GListStore = None):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        if Model == "<<Option>>":
            self.Widget = Gtk.ComboBox.new_with_model(Additional)
        elif Model == "<<Entry>>":
            self.Widget.Gtk.ComboBox.new_with_model_and_entry(Additional)

    def GetTearOffTitle(self):
        self.Widget.get_title()

    def SetTearOffTitle(self, Title: str = "Gib.GControl.GComboBox"):
        self.Widget.set_title(title=Title)

    def HidePop(self):
        self.Widget.popdown()

    def Popup(self):
        self.Widget.popup()


class GComboBoxText(GComboBox):
    def __init__(self):
        super().__init__()
        pass


class GPosition(object):
    def __init__(self):
        self.Init()
        from gi.repository.Gtk import PositionType
        self.Top = PositionType.TOP
        self.Bottom = PositionType.BOTTOM
        self.Left = PositionType.LEFT
        self.Right = PositionType.RIGHT

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")


class GPopover(GComboBox):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Popover()

    def GetConstrain(self):
        return self.Widget.get_constrain_to()

    def SetConstrain(self):
        self.Widget.set_constrain_to()

    def GetPosition(self):
        return self.Widget.get_position()

    def SetPosition(self, Position: GPosition):
        self.Widget.set_position(position=Position)


class GEntry(GEditable):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Entry

    def SetText(self, Text: str):
        self.Widget.set_text(text=Text)

    def SetProgress(self, Value: int):
        self.Widget.set_progress_pulse_step(fraction=Value)

    def GetText(self):
        return self.Widget.get_text()

    def GetTextLength(self):
        return self.Widget.get_text_length()


class GSwitch(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Switch()

    def SetActive(self, Active: bool):
        self.Widget.get_active(is_state=Active)

    def SetState(self, State: bool):
        self.Widget.set_state(state=State)

    def DoActivate(self):
        self.Widget.do_activate()

    def GetActive(self):
        return self.Widget.get_active()

    def GetState(self):
        return self.Widget.get_state()


class GTextView(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.TextView()


class GProgressBar(GWidget):
    def __init__(self, ShowText=False):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.ProgressBar(show_text=ShowText)

    def SetProgress(self, Progress: int = 0):
        self.Widget.set_text(Progress)

    def Pulse(self):
        self.Widget.pulse()


class GBox(GWidget):
    def __init__(self, Spacing: int = 0):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Box(spacing=Spacing)

    def PackStart(self, Widget, Expand: bool = False, Fill: bool = False, Padding: int = 0):
        self.Widget.pack_start(child=Widget, expand=Expand, fill=Fill, padding=Padding)

    def PackEnd(self, Widget, Expand: bool = False, Fill: bool = False, Padding: int = 0):
        self.Widget.pack_end(child=Widget, expand=Expand, fill=Fill, padding=Padding)


class Grid(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Grid()

    def Attach(self, Widget: GWidget, Left: int, Top: int, Width: int, Height: int):
        self.Widget.attach(child=Widget.Get(), left=Left, top=Top, width=Width, height=Height)

    def AttchNextTo(self, Child: GWidget, Sibling: GWidget or None, Side: GPosition, Width: int, Height: int):
        self.Widget.attach_next_to(child=Child, sibling=Sibling, side=Side, width=Width, height=Height)

    def GetWidget(self, Left: int, Top: int):
        return self.Widget.get_child_at(left=Left, top=Top)

    def GetColumnSpacing(self):
        return self.Widget.get_column_spacing()


class GNoteBook(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Notebook()

    def AddPage(self, Widget: GWidget or None, Label: GLabel):
        self.Widget.append_page(child=Widget.Get(), tab_label=Label.Get())

    def AddPages(self, Widget: GWidget or None, Label: str = "Gib.GWidgets.GNoteBook"):
        from gi.repository import Gtk
        self.Widget.append_page(child=Widget.Get(), tab_label=Gtk.Label(label=Label))

    def AddPageMenu(self, Widget: GWidget or None, Label: GLabel,
                    MenuLabel: str = "Gib.GWidgets.GNoteBook"):
        self.Widget.append_page_menu(child=Widget.Get(), tab_label=Label.Get(), menu_label=MenuLabel)

    def SetPageLabel(self, Widget: GWidget, Label: str):
        self.Widget.set_menu_label(child=Widget.Get(), menu_label=Label)

    def SetPageShow(self, Value: bool):
        self.Widget.set_show_tabs(show_tabs=Value)

    def SetScrollable(self, Value: bool):
        self.Widget.set_scrollable(scrollable=Value)

    def RemovePage(self, Page: int = 0):
        self.Widget.remove_page(page_num=Page)

    def DeletePage(self, Widget: GWidget):
        self.Widget.detach_tab(child=Widget.Get())


class GAppChooserWidget(GAppChooser):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.AppChooserWidget()

    def GetDefaultText(self):
        return self.Widget.get_default_text()

    def GetShowDefault(self):
        return self.Widget.get_show_default()

    def GetShowAll(self):
        return self.Widget.get_show_all()

    def GetShowFallback(self):
        return self.Widget.get_show_fallback()

    def GetShowOther(self):
        return self.Widget.get_show_other()

    def GetShowRecommended(self):
        return self.Widget.get_show_recommended()

    def SetDefaultText(self):
        return self.Widget.set_default_text()

    def SetShowDefault(self):
        return self.Widget.set_show_default()

    def SetShowAll(self):
        return self.Widget.set_show_all()

    def SetShowFallback(self):
        return self.Widget.set_show_fallback()

    def SetShowOther(self):
        return self.Widget.set_show_other()

    def SetShowRecommended(self):
        return self.Widget.set_show_recommended()


class GFileChooser(object):
    def __init__(self):
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.FileChooser()

    def AddChoice(self, Id, Label, Option, OptionLabel):
        pass

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")


class GBind(object):
    def __init__(self):
        self.Clicked = "clicked"
        self.Activate = "activate"
        self.Enter = "enter"
        self.Leave = "leave"
        self.Pressed = "pressed"
        self.Released = "released"
        self.Swich_Acitvate = "activate"
        self.Swich_State = "state-set"


class GBuilder(object):
    def __init__(self):
        from gi import require_version
        require_version("Gtk", "3.0")
        from gi.repository import Gtk

        self.Window = None
        self.Widget = Gtk.Builder()

    def Load(self, File):
        self.Widget.add_from_file(File)

    def LoadWidget(self, Object: str):
        return self.Widget.get_object(Object)

    def Get(self):
        return self.Widget

    def GetObjectList(self):
        return self.Widget.get_objects()

    def Run(self, WindowID):
        from gi.repository import Gtk

        self.Window = self.LoadWidget(WindowID)
        self.Window.show_all()
        self.Window.connect("delete-event", Gtk.main_quit)

        Gtk.main()

    def HandleBind(self, Class):
        self.Widget.connect_signals(Class)


class GMenuShell(GWidget):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuShell()

    def AddMenu(self, Widget):
        self.Widget.append(child=Widget.Get())

    def AddMenuItem(self, Widget):
        self.Widget.prepend(child=Widget.Get())

    def Deactivate(self):
        self.Widget.deactivate()

    def Deselect(self):
        self.Widget.deselect()

    def GetParent(self):
        return self.Widget.get_parent_shell()

    def GetSelectItem(self):
        return self.Widget.get_selected_item()

    def Canel(self):
        self.Widget.cancel()


class GMenuBar(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuBar()


class GMenu(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.Menu()

    def SetTearOff(self, State: bool = False):
        self.Widget.set_tearoff_state(torn_off=State)

    def SetTitle(self, Title: str = "Gib.GMenus.GMenu"):
        self.Widget.set_title(title=Title)

    def Detach(self):
        self.Widget.detach()

    def DeleteMenu(self):
        self.Widget.popdown()


class GMenuItem(GMenuShell):
    def __init__(self):
        super().__init__()
        self.Init()
        from gi.repository import Gtk
        self.Widget = Gtk.MenuItem()

    def SetLabel(self, Label: str = "Gib.GMenus.GMenuItem"):
        self.Widget.set_label(label=Label)

    def SetSubMenu(self, Widget):
        self.Widget.set_submenu(Widget)


class GExample(object):
    def __init__(self):
        self.Init()
        self.Code()

    def Init(self):
        from gi import require_version
        require_version("Gtk", "3.0")

    def Code(self):
        pass

    def Run(self):
        pass


class GHelloWorld(GExample):
    def __init__(self):
        super().__init__()
        self.Init()
        from Gib.GContainer import GWindow
        from Gib.GControl import GButton
        self.Window = GWindow()
        self.Window.SetDefaultBounds(450, 200)

        self.Button = GButton(Label="Click Here")
        self.Button.Click(self.Click)
        self.Window.Add(self.Button)

    def Click(self, Widget):
        print("Hello,World")

    def Run(self):
        from gi.repository import Gtk

        self.Window.Event("delete-event", Gtk.main_quit)
        self.Window.ShowAll()
        Gtk.main()


class RGBA(object):
    def __init__(self, Red: float = 1.0, Green: float = 1.0, Blue: float = 1.0, Alpha: float = 1.0):
        from gi.repository import Gdk

        self.Widget = Gdk.RGBA(red=Red, green=Green, blue=Blue, alpha=Alpha)