from Gib.GWidget import GWindow


class GDate(object):
    def __init__(self):
        self.Date = dict()

    def AddDate(self, DateName, DateValue):
        self.Date[DateName] = DateValue

    def SetDate(self, DateName, DateValue):
        self.AddDate(DateName, DateValue)

    def GetDate(self, DateName):
        return self.Date[DateName]


class GProject(object):
    def __init__(self):
        self.Date = GDate()

    def AddWindow(self, WindowId, Window: GWindow):
        self.Date.AddDate(DateName=WindowId, DateValue=Window)

    def SetWindow(self, WindowId, Window: GWindow):
        self.Date.SetDate(DateName=WindowId, DateValue=Window)

    def GetWindow(self, WindowId):
        return self.Date.GetDate(DateName=WindowId)

    def RunWindow(self, WindowId):
        Window = self.GetWindow(WindowId)
        return Window.Get()