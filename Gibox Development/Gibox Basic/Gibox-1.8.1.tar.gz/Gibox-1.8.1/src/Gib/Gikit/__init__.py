class Java(object):
    def RunJava(self, JavaFile):
        import os
        os.system(f"javac {JavaFile}.java")
        os.system(f"java {JavaFile}")

    def GetVersion(self):
        import os
        os.system(f"java -version")


class Windows(object):
    def __init__(self):
        import os

    def WindowsVersion(self):
        import os
        os.system("winver")

    def Sys(self):
        import os
        os.system("sysdm.cpl")

    def Osk(self):
        import os
        os.system("osk")

    def Taskmgr(self):
        import os
        os.system("taskmgr")

    def Regedit(self):
        import os
        os.system("regedit.exe")

    def Cleanmgr(self):
        import os
        os.system(f"cleanmgr")

    def Shutdown(self, Time: int):
        import os
        os.system(f"Shutdown -s -t {Time}")

    def NotePad(self):
        import os
        os.system("notepad")

    def Explorer(self):
        import os
        os.system("explorer")

    def Sound(self):
        import os
        os.system("mmsys.cpl")

    def Control(self):
        import os
        os.system("control")

    def Shutdown_Close(self):
        import os
        os.system(f"shutdown -a")

    def CompMgmtLauncher(self):
        import os
        os.system("CompMgmtLauncher")

    def Cmd(self):
        import os
        os.system(f"cmd.exe")

